package test;

import static org.junit.Assert.*;

import org.junit.Test;

import main.FileHandler;

public class FileHandlerTest {

	@Test
	public void testGetLine() {
		FileHandler fileHandler = new FileHandler();
    	String string1 = fileHandler.getLine("/data/firstNames.txt", 0);
    	assertEquals(string1, "Michael");
    	String string2 = fileHandler.getLine("/data/firstNames.txt", 1000);
    	assertEquals(string2, null);
	}

}
